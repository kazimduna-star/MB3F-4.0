const A = { x: 600, z: -600 }, D = { x: -600, z: 600 }, ENV = 'assets/environment/', GATE = 'assets/dungeons/ancient-gateway.glb', FLOOR = ENV + 'floor_low_poly.glb';
const NATURE = 'assets/environment/nature/', tr = a => a.map(n => NATURE + n + '.gltf');
// Общая конфигурация MB WORLD 3D. Все числа, влияющие на игру и графику, находятся здесь.
export const CONFIG = {
  version: '0.1.0',
  player: { walk: 3.4, run: 7, jumpV: 8.2, gravity: 22, maxHp: 100, radius: 0.45,
    modelUrl: 'assets/characters/aelia.glb', modelScale: 0.337, height: 1.75 /* рост героини в метрах: масштаб вычисляется по реальным размерам модели */ },
  camera: { dist: 7.5, min: 3, max: 14, pitchMin: -0.15, pitchMax: 1.25, fov: 55 },
  bounds: 190,
  pads: [{ x: -42, z: -42, r: 24 }, { x: 105, z: -85, r: 16 }, { x: 70, z: -125, r: 12 }, { x: 95, z: 65, r: 22 }, { x: 0, z: -105, r: 48 }, { x: -100, z: -95, r: 10 },
    { x: A.x, z: A.z, r: 40, h: 80 }, { x: D.x, z: D.z + 12, r: 32, h: 80 }],   // выровненные площадки (h — фиксированная высота)
  // Закрытые области (арена и подземелье): ограничивают движение героини и камеру. rect — смещения от (cx, cz).
  areas: [{ cx: A.x, cz: A.z, r: 22 }, { cx: D.x, cz: D.z + 12, rect: [-10.2, 10.2, -22.6, 22.8] }],
  teleports: {
    arena: { zone: 'arena', x: A.x, z: A.z + 12, facing: Math.PI }, back: { zone: 'valley', x: 70, z: -120, facing: 0 },
    dungeon: { zone: 'dungeon', x: D.x, z: D.z - 6, facing: 0 }, dungeonExit: { zone: 'valley', x: -100, z: -88, facing: 0 }
  },
  zones: [
    { id: 'valley', name: 'Долина Пробуждения', x: 0, z: 0, radius: 120, builder: 'valley', assets: [],
      scatter: [
        { urls: tr(['CommonTree_1', 'CommonTree_2', 'CommonTree_3', 'CommonTree_4', 'CommonTree_5']), n: 80, s: [.9, 1.4], g: 'trees', col: { r: .5, h: 7 } },
        { urls: tr(['Pine_1', 'Pine_2', 'Pine_3', 'Pine_4', 'Pine_5']), n: 80, s: [.9, 1.5], g: 'trees', col: { r: .5, h: 7 } },
        { urls: tr(['TwistedTree_1', 'TwistedTree_2', 'TwistedTree_3']), n: 18, s: [.9, 1.3], g: 'trees', col: { r: .55, h: 7 } },
        { urls: tr(['DeadTree_1', 'DeadTree_2']), n: 6, s: [.9, 1.2], g: 'trees', col: { r: .5, h: 6 } },
        { urls: [ENV + 'tree_2_5.glb'], n: 25, s: [.8, 1.3], fit: { h: 8 }, g: 'trees', col: { r: .6, h: 7 } },
        { urls: [ENV + 'stylized_rock.glb'], n: 20, s: [.8, 1.8], fit: { h: 2.4 }, g: 'env', col: { r: 1.2, h: 2 } },
        { urls: tr(['Rock_Medium_1', 'Rock_Medium_2', 'Rock_Medium_3']), n: 36, s: [.8, 2], g: 'env', col: { r: 1.1, h: 1.8 }, hMax: 20 },
        { urls: tr(['Bush_Common', 'Bush_Common_Flowers']), n: 70, s: [.8, 1.4], g: 'env' },
        { urls: tr(['Fern_1', 'Plant_1_Big', 'Plant_7_Big']), n: 70, s: [.8, 1.3], g: 'env' },
        { urls: tr(['Flower_3_Group', 'Flower_4_Group']), n: 90, s: [.8, 1.3], g: 'env' },
        { urls: tr(['Mushroom_Common', 'Mushroom_Laetiporus']), n: 20, s: [.8, 1.3], g: 'env' },
        { urls: tr(['Pebble_Round_1', 'Pebble_Round_2', 'Pebble_Square_1']), n: 50, s: [.8, 1.6], g: 'env' }],
      props: [
        { url: ENV + 'isle_of_plenty.glb', x: -150, z: -170, y: 55, fit: { m: 120 }, merge: true, noShadow: true, minEnv: .7 },   // 17 текстур 2048² (около 380 МБ видеопамяти): только «Высокое» и выше. Парящий Остров Изобилия (2191 меш слиты по материалам)
        { url: ENV + 'meadow_patch.glb', x: 30, z: -45, fit: { m: 6 }, minEnv: .9 },      // 925 тыс. треугольников: только «Очень высокое» и выше
        { url: ENV + 'rock_outcrop.glb', x: 80, z: 20, fit: { m: 14 }, minEnv: 1 }],     // 1,9 млн треугольников, файл 115 МБ: только «Максимальное»
      monsters: [{ id: 'rotwalker', x: 35, z: 25 }, { id: 'rotwalker', x: 45, z: 40 }, { id: 'rotwalker', x: 60, z: -10 }, { id: 'ossuary-legionary', x: -50, z: -20 }, { id: 'ossuary-legionary', x: 70, z: 40 }] },
    { id: 'village', name: 'Деревня Тихий Ручей', x: -42, z: -42, radius: 30, builder: 'empty', assets: [], poi: '#ffd86b',
      npcs: [{ id: 'borin', name: 'Староста Борин', x: -42, z: -39, color: 0x8a5a2b }, { id: 'mira', name: 'Торговка Мира', x: -37, z: -42, color: 0xb04a6a }],
      village: { houses: [
        { x: 0, z: -13, rot: Math.PI, n: 3 }, { x: -13, z: 0, rot: -Math.PI / 2, n: 3 }, { x: 13, z: 0, rot: Math.PI / 2, n: 3 },
        { x: -9, z: 12, rot: 0, n: 2, brick: true }, { x: 9, z: 12, rot: 0, n: 2, brick: true }] } },
    { id: 'city', name: 'Город Аэрис', x: 0, z: -105, radius: 50, builder: 'empty', assets: [], poi: '#ff9d5c',
      npcs: [{ id: 'edrik', name: 'Торговец Эдрик', x: 4, z: -93, color: 0x9a6a2f }, { id: 'guard', name: 'Страж Рагнар', x: 3, z: -68, color: 0x6a6f86 }],
      city: {
        houses: [   // координаты относительно центра города; дверь дома смотрит на улицу
          { x: -30, z: 5, rot: Math.PI, n: 3, lv: 2 }, { x: -21, z: 5, rot: Math.PI, n: 3, lv: 2, brick: true }, { x: -12, z: 5, rot: Math.PI, n: 3, lv: 2 },
          { x: 12, z: 5, rot: Math.PI, n: 3, lv: 2 }, { x: 21, z: 5, rot: Math.PI, n: 3, lv: 2, brick: true }, { x: 30, z: 5, rot: Math.PI, n: 3, lv: 2 },
          { x: -28, z: 21, rot: 0, n: 3, lv: 2, brick: true }, { x: -19, z: 21, rot: 0, n: 3, lv: 2 }, { x: -10, z: 21, rot: 0, n: 2, lv: 2 },
          { x: 10, z: 21, rot: 0, n: 2, lv: 2 }, { x: 19, z: 21, rot: 0, n: 3, lv: 2 }, { x: 28, z: 21, rot: 0, n: 3, lv: 2, brick: true },
          { x: -26, z: -18, rot: -Math.PI / 2, n: 3, lv: 2 }, { x: -26, z: -28, rot: -Math.PI / 2, n: 2, lv: 2 },
          { x: 26, z: -18, rot: Math.PI / 2, n: 3, lv: 2 }, { x: 26, z: -28, rot: Math.PI / 2, n: 2, lv: 2 }],
        roads: [[[0, -9], [0, -70]], [[0, -35], [-12, -40], [-34, -41]], [[36, -93], [52, -105], [66, -118]], [[-36, -93], [-60, -94], [-92, -94]], [[0, -9], [40, 10], [80, 50], [92, 60]]] } },
    { id: 'village2', name: 'Деревня Каменный Брод', x: 95, z: 65, radius: 28, builder: 'empty', assets: [], poi: '#ffd86b',
      npcs: [{ id: 'lisa', name: 'Охотница Лиса', x: 97, z: 65, color: 0x3f8f5a }, { id: 'ion', name: 'Рыбак Ион', x: 91, z: 68, color: 0x4a7ab0 }],
      village: { houses: [
        { x: 0, z: -12, rot: Math.PI, n: 3 }, { x: -12, z: 4, rot: -Math.PI / 2, n: 2, brick: true },
        { x: 12, z: 4, rot: Math.PI / 2, n: 2, brick: true }, { x: 0, z: 15, rot: 0, n: 3 }] } },
    { id: 'portal', name: 'Древний портал', x: 70, z: -125, radius: 30, builder: 'portal', poi: '#b99cff', portal: { w: 3, h: 3.6, sx: 0, sy: 2.9, sz: -2.07 },
      props: [{ url: GATE, x: 70, z: -125, fit: { w: 9 } }, { url: FLOOR, x: 70, z: -125, fit: { w: 3 }, dy: -.31, grid: { r: 8, step: 3 } }] },
    { id: 'dungeon_gate', name: 'Вход в подземелье', x: -100, z: -95, radius: 25, builder: 'entrance', poi: '#5fe0b0', portal: { w: 3.4, h: 4.2, sx: 0, sy: 2.1, sz: 0 },
      props: [{ url: ENV + 'stylized_rock.glb', x: -100, z: -95, at: [[-3.2, 0, .3], [3.2, 0, 2.8]], fit: { h: 5 } }] },
    { id: 'arena', name: 'Арена Стража', x: A.x, z: A.z, radius: 40, builder: 'arena', portal: { w: 3, h: 3.6, sx: 0, sy: 2.9, sz: 17.93 },
      props: [{ url: GATE, x: A.x, z: A.z + 20, fit: { w: 9 } }, { url: FLOOR, x: A.x, z: A.z, fit: { w: 4 }, dy: -.42, grid: { r: 19, step: 4 } },
        { url: ENV + 'icicles.glb', x: A.x, z: A.z, at: [[-17, -8, .5], [17, -10, -.5]], fit: { h: 7 }, noShadow: true }],
      monsters: [{ id: 'lucifer-avatar', x: A.x, z: A.z - 8 }] },
    { id: 'dungeon', name: 'Водно-каменное подземелье', x: D.x, z: D.z + 12, radius: 40, builder: 'dungeon',
      props: [{ url: 'assets/dungeons/water-stone-dungeon.glb', x: D.x, z: D.z, y: 80 }],
      monsters: [{ id: 'ossuary-legionary', x: D.x - 4, z: D.z + 10 }, { id: 'ossuary-legionary', x: D.x + 4, z: D.z + 16 }, { id: 'ossuary-legionary', x: D.x, z: D.z + 22 }, { id: 'the-apostate', x: D.x, z: D.z + 30 }, { id: 'burning-reliquary', x: D.x + 6, z: D.z + 26 }, { id: 'the-unborn', x: D.x - 6, z: D.z + 26 }] },
    { id: 'ruins', name: 'Древние руины', x: 105, z: -85, radius: 40, builder: 'ruins', assets: [], poi: '#c9c9d9',
      monsters: [{ id: 'chainwraith', x: 95, z: -75 }, { id: 'broken-cherub', x: 116, z: -96 }, { id: 'necromancer', x: 108, z: -100 }, { id: 'blind-seraph', x: 112, z: -72 }] }
  ],
  tips: [
    'Исследуйте мир, находите скрытые сундуки и открывайте новые возможности!',
    'Двумя пальцами можно приближать и отдалять камеру.',
    'Кнопку «Бег» можно включить постоянно или оставить автобег джойстиком.',
    'Расположение кнопок можно изменить в настройках управления.'
  ]
};

export const PRESET_NAMES = ['Низкое', 'Среднее', 'Высокое', 'Очень высокое', 'Максимальное'];

// Значения для каждого из 5 уровней каждого параметра графики.
export const GFX = {
  grass: [{ r: 0, s: 1 }, { r: 16, s: 1.1 }, { r: 24, s: .85 }, { r: 32, s: .7 }, { r: 40, s: .6 }],
  trees: [.2, .45, .7, .9, 1],
  environment: [.2, .45, .7, .9, 1],
  textures: [1, 2, 4, 8, 16],
  water: [0, 32, 64, 96, 128],
  shadows: [0, 1024, 1536, 2048, 4096],
  lighting: [
    { sun: 1, hemi: .9, glow: 0, tone: false }, { sun: 1.1, hemi: .8, glow: 0, tone: true },
    { sun: 1.25, hemi: .7, glow: 0, tone: true }, { sun: 1.3, hemi: .65, glow: 6, tone: true },
    { sun: 1.4, hemi: .6, glow: 12, tone: true }],
  draw: [{ far: 180, fog: .013, zone: 50 }, { far: 260, fog: .0095, zone: 70 }, { far: 380, fog: .0065, zone: 90 },
    { far: 520, fog: .0045, zone: 110 }, { far: 720, fog: .003, zone: 140 }],
  effects: [0, 40, 100, 200, 400],
  character: [0, 1, 2, 3, 4],
  resolution: [1, 1.25, 1.75, 2.25, 3]
};

export const GFX_ROWS = [
  ['grass', 'Качество травы', l => l ? `Радиус ${GFX.grass[l].r} м` : 'Выключена'],
  ['trees', 'Качество деревьев', l => `Плотность ${Math.round(GFX.trees[l] * 100)}%`],
  ['textures', 'Качество текстур', l => `Фильтрация ×${GFX.textures[l]} (разрешение не снижается)`],
  ['water', 'Качество воды', l => l ? `Волны, ${GFX.water[l]} сегм.` : 'Плоская поверхность'],
  ['shadows', 'Качество теней', l => l ? `Карта ${GFX.shadows[l]} px` : 'Выключены'],
  ['lighting', 'Качество освещения', l => ['Базовое', 'Тональная коррекция', 'Усиленный контраст', 'Свечение героини', 'Сильное свечение'][l]],
  ['draw', 'Дальность прорисовки', l => `${GFX.draw[l].far} м, подгрузка зон ${GFX.draw[l].zone} м`],
  ['environment', 'Качество окружения', l => `Плотность ${Math.round(GFX.environment[l] * 100)}%` + (l >= 3 ? ', + тяжёлые модели' : '')],
  ['effects', 'Эффекты и частицы', l => l ? `${GFX.effects[l]} светлячков` : 'Выключены'],
  ['character', 'Качество персонажа', l => l < 2 ? 'Тень героини выключена' : 'Тень героини включена. Модель и текстуры не меняются'],
  ['resolution', 'Разрешение рендера', l => `До ×${GFX.resolution[l]} от плотности экрана`]
];

export const DEFAULT_CONTROLS = { joySize: 1, btnSize: 1, opacity: .85, camSens: 1, autoRun: true, camMode: 'third', camInvert: false, debug: false, layout: {} };

// s: 'l' — отступ слева, 'r' — отступ справа; x,y — пиксели от края; size — базовый размер.
export const DEFAULT_LAYOUT = {   // размеры заданы для экрана высотой около 430 px и масштабируются под устройство
  joy: { s: 'l', x: 20, y: 20, size: 96 },
  run: { s: 'l', x: 126, y: 30, size: 34 },
  attack: { s: 'r', x: 24, y: 56, size: 56 },
  heavy: { s: 'r', x: 86, y: 96, size: 40 },
  skill: { s: 'r', x: 90, y: 46, size: 42 },
  jump: { s: 'r', x: 28, y: 120, size: 40 },
  dodge: { s: 'r', x: 24, y: 8, size: 38 },
  interact: { s: 'r', x: 140, y: 70, size: 42 }
};
