import { CONFIG } from '../config.js';

const el = (cls, parent, html = '', tag = 'div') => { const e = document.createElement(tag); e.className = cls; e.innerHTML = html; parent?.appendChild(e); return e; };
const STAR = '<svg viewBox="0 0 48 48"><path d="M24 2l4.5 17.5L46 24l-17.5 4.5L24 46l-4.5-17.5L2 24l17.5-4.5z" fill="#fff" stroke="#b9a6ff" stroke-width="1.5" stroke-linejoin="round"/></svg>';
export const logo = (big = false) => el('logo' + (big ? ' big' : ''), null, `<span class="logo-star">${STAR}</span><span class="logo-text">MB WORLD<br><i>3D</i></span>`);
const ico = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;

export class Menus {
  constructor(host, h) {
    this.h = h; this.host = host;
    this.loading = el('screen splash', host); this.loading.append(logo(true)); el('tagline', this.loading, '<span></span>Открой свой мир<span></span>');
    const tip = el('tip', this.loading, `<b>Совет:</b><div>${CONFIG.tips[Math.floor(Math.random() * CONFIG.tips.length)]}</div>`);
    const bar = el('lbar', this.loading); this.fill = el('lbar-fill', bar); this.lbl = el('lbl', this.loading, 'Загрузка... 0%');
    this.main = el('screen splash hidden', host); this.main.append(logo(true)); el('tagline', this.main, '<span></span>Открой свой мир<span></span>');
    const top = el('top-menu', this.main);
    [['settings', 'Настройки', ico('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>')], ['help', 'Помощь', ico('<path d="M9 9a3 3 0 1 1 4 2.8c-.7.4-1 1-1 1.7M12 17.5v.5"/>')]].forEach(([id, t, i]) => { const b = el('top-btn', top, `<span>${i}</span>${t}`, 'button'); b.onclick = () => id === 'settings' ? h.settings() : this.help(); });
    this.start = el('pill big', this.main, 'Начать игру', 'button'); this.start.onclick = () => h.start();
    this.pause = el('screen dim hidden', host); const pc = el('menu-card', this.pause); pc.append(logo()); el('card-title', pc, 'Пауза');
    [['Продолжить', () => h.resume()], ['Настройки', () => h.settings()], ['Выйти в главное меню', () => location.reload()]].forEach(([t, f], i) => { const b = el('pill wide' + (i ? ' ghost' : ''), pc, t, 'button'); b.onclick = f; });
  }
  setProgress(p, text) { this.fill.style.width = p + '%'; this.lbl.textContent = `${text || 'Загрузка...'} ${Math.round(p)}%`; }
  showMain() { this.loading.classList.add('hidden'); this.main.classList.remove('hidden'); }
  hideMain() { this.main.classList.add('hidden'); }
  showPause(on) { this.pause.classList.toggle('hidden', !on); }
  help() {
    const r = el('screen dim', this.host), c = el('menu-card widecard', r); c.append(logo()); el('card-title', c, 'Управление');
    el('help', c, `<p><b>Левая часть экрана</b> — джойстик движения. Полное отклонение включает бег.</p><p><b>Правая часть экрана</b> — свободное вращение камеры. Двумя пальцами — приближение и отдаление.</p>
      <p><b>Кнопки:</b> атака (удерживайте для серии), сильная атака, способность, прыжок, уклонение, бег (переключатель) и взаимодействие рядом с объектами.</p>
      <p>На компьютере: WASD, пробел, Shift, J, K, Q, E, R, мышь и колесо.</p>`);
    const b = el('pill wide', c, 'Закрыть', 'button'); b.onclick = () => r.remove();
  }
}
