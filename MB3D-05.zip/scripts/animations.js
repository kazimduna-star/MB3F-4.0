import * as THREE from 'three';
// Шаблоны имён клипов. Когда у Аэлии появится модель, клипы подбираются по имени автоматически.
export const CLIP_PATTERNS = { idle: /idle|stand/i, walk: /walk/i, run: /run|sprint/i, jump: /jump/i, attack: /attack|slash/i, dodge: /dodge|roll|dash/i, death: /death|die/i };
const ONCE = ['jump', 'attack', 'dodge', 'death'];


// Процедурная анимация костей: в модели Аэлии НЕТ анимационных клипов. Заменится настоящими клипами автоматически.
const PAT = { sp1: /^spine_01/, sp2: /^spine_02/, sp3: /^spine_03/, head: /^head/, armL: /^arm_stretch\.?l_/, armR: /^arm_stretch\.?r_/, foreL: /^forearm_stretch\.?l_/, foreR: /^forearm_stretch\.?r_/,
  thL: /^thigh_stretch\.?l_/, thR: /^thigh_stretch\.?r_/, shL: /^leg_stretch\.?l_/, shR: /^leg_stretch\.?r_/, ftL: /^foot\.?l_/, ftR: /^foot\.?r_/ };
const _q = new THREE.Quaternion(), _e = new THREE.Euler();
class RigPose {
  constructor(root) {
    root.updateMatrixWorld(true); const bones = [], qr = root.getWorldQuaternion(new THREE.Quaternion()).invert(); this.b = {}; this.p = {}; this.phase = 0; this.t = 0;
    root.traverse(o => o.isBone && bones.push(o));
    for (const [k, re] of Object.entries(PAT)) {
      const bone = bones.find(o => re.test(o.name)); if (!bone) continue;
      const P = bone.parent.getWorldQuaternion(new THREE.Quaternion()).premultiply(qr);   // поза покоя родителя в осях модели
      this.b[k] = { bone, rest: bone.quaternion.clone(), P, Pi: P.clone().invert() };
    }
    this.missing = Object.keys(PAT).filter(k => !this.b[k]);
  }
  set(k, x, y = 0, z = 0) { const e = this.b[k]; if (!e) return; _q.setFromEuler(_e.set(x, y, z, 'XYZ')); e.bone.quaternion.copy(e.Pi).multiply(_q).multiply(e.P).multiply(e.rest); const w = e.bone.quaternion; if (!(w.x === w.x && w.y === w.y && w.z === w.z && w.w === w.w)) w.copy(e.rest); }
  update(dt, s) {
    this.t += dt; const sp = Math.min(1, s.speed / 7), mv = s.state === 'walk' || s.state === 'run', T = { sw: 0, kn: 0, ar: 0, ln: 0, cr: 0, tk: 0, at: 0 };
    if (mv) { T.sw = .25 + .7 * sp; T.kn = .3 + .8 * sp; T.ar = .3 + .6 * sp; T.ln = .05 + .25 * sp; }
    if (s.state === 'jump') { T.tk = 1; T.ar = .5; } if (s.state === 'dodge') { T.ln = .8; T.cr = .6; }
    if (s.state === 'attack') T.at = Math.max(.001, Math.min(1, s.attackP));
    for (const k in T) this.p[k] = (this.p[k] ?? 0) + (T[k] - (this.p[k] ?? 0)) * Math.min(1, dt * 12);
    const p = this.p; this.phase += dt * (3 + s.speed); const A = Math.sin(this.phase), B = -A, br = Math.sin(this.t * 2) * .02;
    const kn = f => p.kn * Math.max(0, Math.sin(this.phase + f + 1.2)), thL = -(p.sw * A) - p.tk - p.cr, thR = -(p.sw * B) - p.tk * .8 - p.cr, shL = kn(0) + p.tk * 1.4 + p.cr * 1.6, shR = kn(Math.PI) + p.tk * 1.1 + p.cr * 1.6;
    this.set('thL', thL); this.set('thR', thR); this.set('shL', shL); this.set('shR', shR); this.set('ftL', -(thL + shL) * .5); this.set('ftR', -(thR + shR) * .5);
    const aw = Math.sin(p.at * Math.PI);
    this.set('armL', p.ar * A - p.tk * 1.2, 0, -.4); this.set('armR', -p.ar * A - p.tk * 1.2 - aw * 2.2, 0, .4 * (1 - p.at));
    this.set('foreL', -(.4 + .4 * sp * (mv ? 1 : 0))); this.set('foreR', -(.4 + .4 * sp * (mv ? 1 : 0)) - aw * .6);
    this.set('sp1', p.ln * .4 + br, aw * .3); this.set('sp2', p.ln * .3 + br); this.set('sp3', p.ln * .3); this.set('head', -p.ln * .5);
    return { y: -p.cr * .25 };
  }
}

export class Animator {
  constructor(node) { this.node = node; this.mixer = null; this.actions = {}; this.current = null; this.t = 0; this.missing = []; }
  setModel(obj, clips) {
    this.rig = null; this.mixer = null; this.actions = {};
    if (!clips.length) { this.rig = new RigPose(obj); this.missing = this.rig.missing; this.node.scale.set(1, 1, 1); return; }
    this.mixer = new THREE.AnimationMixer(obj);
    for (const [k, re] of Object.entries(CLIP_PATTERNS)) {
      const c = clips.find(x => re.test(x.name)); if (!c) continue;
      const a = this.mixer.clipAction(c); if (ONCE.includes(k)) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; } this.actions[k] = a;
    }
    this.missing = Object.keys(CLIP_PATTERNS).filter(k => !this.actions[k]);
    this.node.scale.set(1, 1, 1); this.node.rotation.x = 0; this.node.position.y = 0;
  }
  play(name) {
    const a = this.actions[name] || this.actions.idle; if (!a || a === this.current) return;
    a.reset().fadeIn(.15).play(); if (this.current) this.current.fadeOut(.15); this.current = a;
  }
  update(dt, s) {
    this.t += dt;
    if (this.rig) { const r = this.rig.update(dt, s); this.node.position.y = r.y; this.node.rotation.x = s.state === 'death' ? -1.4 : 0; return; }
    if (this.mixer) { this.play(s.state); this.mixer.update(dt); return; }
    // Процедурная поза капсулы-заглушки
    let sy = 1, sxz = 1, lean = 0, y = 0; const t = this.t;
    switch (s.state) {
      case 'idle': sy = 1 + Math.sin(t * 2.2) * .02; break;
      case 'walk': y = Math.abs(Math.sin(t * 9)) * .07; lean = .1; break;
      case 'run': y = Math.abs(Math.sin(t * 14)) * .1; lean = .28; break;
      case 'jump': sy = 1.12; sxz = .92; lean = .1; break;
      case 'attack': lean = .55 * Math.sin(Math.min(1, s.attackP) * Math.PI); break;
      case 'dodge': sy = .6; sxz = 1.25; lean = .7; break;
      case 'death': sy = .35; sxz = 1.4; break;
    }
    this.node.scale.set(sxz, sy, sxz); this.node.position.y = y; this.node.rotation.x = lean;
  }
}
