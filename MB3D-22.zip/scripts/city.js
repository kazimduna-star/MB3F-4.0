import * as THREE from 'three';
import { heightAt } from './world.js';

// Город с замком из модульных деталей Medieval Village MegaKit (сетка 2 м, высота стены 3,12 м).
// Координаты в config.zones[city].city заданы относительно центра города; «юг» города (+z) обращён к стартовой долине.
const A = 'assets/buildings/medieval/', L = 3.12;
export async function buildCity(def, cache) {
  const C = def.city, group = new THREE.Group(), colliders = [], B = {}, q = new THREE.Quaternion(), p = new THREE.Vector3(), one = new THREE.Vector3(1, 1, 1), up = new THREE.Vector3(0, 1, 0);
  const put = (name, x, y, z, ry) => (B[name] ??= []).push(new THREE.Matrix4().compose(p.set(x, y, z), q.setFromAxisAngle(up, ry), one));
  const col = (x, z, r, h) => colliders.push({ x, z, r, h, active: true });
  const W = (lx, lz) => [def.x + lx, def.z + lz];
  // Ряд стен от (x0,z0) до (x1,z1) каждые 2 м. ry — поворот наружу (-z у модели). gap(x,z) — проём: вместо стены арка.
  function run(x0, z0, x1, z1, ry, lv, piece, gap) {
    const n = Math.round(Math.hypot(x1 - x0, z1 - z0) / 2), ox = -Math.sin(ry), oz = -Math.cos(ry);
    for (let i = 0; i <= n; i++) {
      const lx = x0 + (x1 - x0) * i / n, lz = z0 + (z1 - z0) * i / n, [wx, wz] = W(lx - .2 * ox, lz - .2 * oz), y = heightAt(wx, wz), isGap = gap?.(lx, lz);
      for (let k = 0; k < lv; k++) put(isGap && k === 0 ? 'Wall_Arch' : piece, wx, y + k * L, wz, ry);
      if (!isGap) col(wx, wz, 1.05, L * lv);
    }
  }
  function tower(lx, lz, lv) {
    const [cx, cz] = W(lx, lz), y = heightAt(cx, cz);
    [[0, -1, 0], [0, 1, Math.PI], [1, 0, -Math.PI / 2], [-1, 0, Math.PI / 2]].forEach(([nx, nz, ry]) => {
      for (let i = 0; i < 3; i++) {
        const t = -2 + 2 * i, wx = cx + (nz ? t : nx * 2.8), wz = cz + (nz ? nz * 2.8 : t);
        for (let k = 0; k < lv; k++) put('Wall_UnevenBrick_Straight', wx, y + k * L, wz, ry);
      }
    });
    for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) for (let k = 0; k < lv; k++) put('Corner_Exterior_Brick', cx + sx * 3, y + k * L, cz + sz * 3, 0);
    put('Roof_Tower_RoundTiles', cx, y + lv * L, cz, 0); col(cx, cz, 3.4, L * lv + 4);
  }
  function house(h) {
    const n = h.n, lv = h.lv || 1, c = Math.cos(h.rot), s = Math.sin(h.rot), [hx, hz] = W(h.x, h.z), y = heightAt(hx, hz);
    const loc = (lx, lz, la, name, k = 0, dy = 0) => { const wx = hx + lx * c + lz * s, wz = hz - lx * s + lz * c; put(name, wx, y + k * L + dy, wz, h.rot + la); return [wx, wz]; };
    const base = h.brick ? 'Wall_UnevenBrick_' : 'Wall_Plaster_', str = base + 'Straight', door = base + 'Door_Round', win = h.brick ? 'Wall_UnevenBrick_Window_Wide_Round' : 'Wall_Plaster_Window_Wide_Round';
    [[0, -1, 0], [0, 1, Math.PI], [1, 0, -Math.PI / 2], [-1, 0, Math.PI / 2]].forEach(([nx, nz, la], si) => {
      for (let i = 0; i < n; i++) {
        const t = -n + 1 + 2 * i, isDoor = si === 0 && i === 1;
        for (let k = 0; k < lv; k++) {
          const name = k === 0 ? (isDoor ? door : (i === 1 ? win : str)) : (i === 1 ? win : str), [wx, wz] = nz ? loc(t, nz * (n - .2), la, name, k) : loc(nx * (n - .2), t, la, name, k);
          if (k === 0 && !isDoor) col(wx, wz, 1, L * lv + .5);
        }
      }
    });
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) loc(-n + 1 + 2 * i, -n + 1 + 2 * j, 0, 'Floor_WoodDark', 0, .08);
    for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) for (let k = 0; k < lv; k++) loc(sx * n, sz * n, 0, h.brick ? 'Corner_Exterior_Brick' : 'Corner_Exterior_Wood', k);
    loc(0, 0, 0, n === 3 ? 'Roof_RoundTiles_6x6' : 'Roof_RoundTiles_4x4', 0, lv * L - .02);
  }
  const tile = (name, lx, lz, ry = 0) => { const [x, z] = W(lx, lz); put(name, x, heightAt(x, z) + .03, z, ry); };
  // Городская стена с четырьмя башнями и тремя воротами (юг, запад, восток)
  const gapS = lx => Math.abs(lx) < 1, gapSide = (lx, lz) => Math.abs(lz - 12) < 1;
  for (const [x, z] of [[-32, -32], [32, -32], [-32, 32], [32, 32]]) tower(x, z, 3);
  run(-28, -35, 28, -35, 0, 2, 'Wall_UnevenBrick_Straight'); run(-28, 35, 28, 35, Math.PI, 2, 'Wall_UnevenBrick_Straight', gapS);
  run(35, -28, 35, 28, -Math.PI / 2, 2, 'Wall_UnevenBrick_Straight', gapSide); run(-35, -28, -35, 28, Math.PI / 2, 2, 'Wall_UnevenBrick_Straight', gapSide);
  // Замок: четыре башни, стены, главная башня-донжон и вымощенный двор
  for (const [x, z] of [[-11, -8], [11, -8], [-11, -30], [11, -30]]) tower(x, z, 3);
  run(-7, -8, 7, -8, Math.PI, 2, 'Wall_UnevenBrick_Straight', lx => Math.abs(lx) < 2); run(-7, -30, 7, -30, 0, 2, 'Wall_UnevenBrick_Straight');
  run(-11, -26, -11, -12, Math.PI / 2, 2, 'Wall_UnevenBrick_Straight'); run(11, -26, 11, -12, -Math.PI / 2, 2, 'Wall_UnevenBrick_Straight');
  house({ x: 0, z: -19, rot: Math.PI, n: 3, lv: 3, brick: true });
  for (let i = -4; i <= 4; i++) for (let j = -14; j <= -5; j++) tile('Floor_UnevenBrick', i * 2, j * 2);
  // Дома, улицы, площадь
  C.houses.forEach(house);
  for (let z = 35; z >= -6; z -= 2) { tile('Floor_UnevenBrick', -1, z); tile('Floor_UnevenBrick', 1, z); }
  for (let x = -34; x <= 34; x += 2) { tile('Floor_UnevenBrick', x, 11); tile('Floor_UnevenBrick', x, 13); }
  for (let x = -4; x <= 4; x += 2) for (let z = 8; z <= 16; z += 2) tile('Floor_Brick', x, z);
  [[6, 19, .5], [-6, 19, 2]].forEach(([x, z, r]) => { const [wx, wz] = W(x, z); put('Prop_Wagon', wx, heightAt(wx, wz), wz, r); col(wx, wz, 1.6, 1.5); });
  [[5, 8], [-5, 8.5], [7, 15], [-7, 15.5], [3, 17]].forEach(([x, z], i) => { const [wx, wz] = W(x, z); put('Prop_Crate', wx, heightAt(wx, wz), wz, i); col(wx, wz, .7, 1.1); });
  // Дороги от города к деревням, порталу и подземелью: плитки по ломаным линиям в мировых координатах
  for (const line of C.roads) for (let s = 0; s < line.length - 1; s++) {
    const [ax, az] = line[s], [bx, bz] = line[s + 1], len = Math.hypot(bx - ax, bz - az), n = Math.ceil(len / 1.6), ry = Math.atan2(bx - ax, bz - az);
    for (let i = 0; i <= n; i++) { const x = ax + (bx - ax) * i / n, z = az + (bz - az) * i / n; put('Floor_UnevenBrick', x, heightAt(x, z) + .03, z, ry); }
  }
  for (const name of Object.keys(B)) {
    try { (await cache.instanced(A + name + '.gltf', B[name])).forEach(m => group.add(m)); } catch (e) { console.warn('Не загружено', name, e); }
  }
  return { group, colliders };
}
