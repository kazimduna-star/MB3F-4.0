import { state as S, setLayout } from './settings.js';
import { DEFAULT_LAYOUT } from '../config.js';

const SV = (d, f) => `<svg viewBox="0 0 24 24" fill="${f ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ICON = {
  attack: SV('<path d="M20 4L10 14M8 12l4 4M10 14l-5 5"/>'), heavy: SV('<path d="M20 3L9 14M6 11l6 6M9 14l-5 6M21 10l-7 7"/>'),
  skill: SV('<path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/>', 1), jump: SV('<path d="M6 13l6-6 6 6M6 20l6-6 6 6"/>'),
  dodge: SV('<path d="M3 8h6M3 16h6M8 12h12M15 7l5 5-5 5"/>'), interact: SV('<path d="M12 3l9 9-9 9-9-9z"/><path d="M12 8v5M12 16v.5"/>'), run: SV('<path d="M5 6l6 6-6 6M12 6l6 6-6 6"/>')
};
const KEYS = { Space: 'jump', ShiftLeft: 'dodge', KeyJ: 'attack', KeyK: 'heavy', KeyQ: 'skill', KeyE: 'interact', KeyR: 'run' };
const el = (cls, parent, tag = 'div') => { const e = document.createElement(tag); e.className = cls; parent?.appendChild(e); return e; };

export class Input {
  constructor(host) {
    this.move = { x: 0, y: 0 }; this.cam = { x: 0, y: 0 }; this.zoom = 0; this.queue = []; this.held = new Set(); this.keys = new Set();
    this.runToggle = false; this.enabled = false; this.editing = false; this.interactOn = false; this.els = {}; this.joyId = null;
    const L = this.layer = el('controls hidden', host);
    this.camArea = el('cam-area', L); this.joyArea = el('joy-area', L);
    this.els.joy = el('joy-base', L); this.knob = el('joy-knob', this.els.joy);
    for (const id of ['run', 'attack', 'heavy', 'skill', 'jump', 'dodge', 'interact']) {
      const b = this.els[id] = el('cbtn b-' + id, L, 'button'); b.innerHTML = ICON[id] + '<span class="cd"></span>'; b.setAttribute('aria-label', id);
      if (id === 'interact') { b.classList.add('off'); this.cap = el('cap', b, 'span'); }
      b.addEventListener('pointerdown', e => { if (this.editing) return; e.preventDefault(); e.stopPropagation(); b.setPointerCapture(e.pointerId); b.classList.add('down'); this._fire(id, true); });
      const up = e => { b.classList.remove('down'); this.held.delete(id); };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
    }
    this._bindJoystick(); this._bindCamera(); this._bindEdit(); this._bindKeys();
    L.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
    document.addEventListener('gesturestart', e => e.preventDefault()); document.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('resize', () => this.applyLayout()); this.applyLayout();
  }
  setEnabled(on) { this.enabled = on; this.layer.classList.toggle('hidden', !on); if (!on) { this._releaseJoy(); this.held.clear(); } }
  _fire(act, down) {
    if (!this.enabled) return;
    if (act === 'run') { this.runToggle = !this.runToggle; this.els.run.classList.toggle('on', this.runToggle); return; }
    if (act === 'interact' && !this.interactOn) return;
    this.queue.push(act); if (down && act === 'attack') this.held.add('attack');
  }
  isHeld(a) { return this.held.has(a); }
  _bindJoystick() {
    const area = this.joyArea, base = this.els.joy;
    area.addEventListener('pointerdown', e => {
      if (this.editing || this.joyId !== null) return; e.preventDefault(); this.joyId = e.pointerId; area.setPointerCapture(e.pointerId);
      this.joyR = base.offsetWidth / 2; this.ox = e.clientX; this.oy = e.clientY; base.style.left = this.ox - this.joyR + 'px'; base.style.bottom = innerHeight - this.oy - this.joyR + 'px'; base.style.right = 'auto'; base.classList.add('active'); this._joyMove(e);
    });
    area.addEventListener('pointermove', e => { if (e.pointerId === this.joyId) this._joyMove(e); });
    const up = e => { if (e.pointerId === this.joyId) this._releaseJoy(); };
    area.addEventListener('pointerup', up); area.addEventListener('pointercancel', up);
  }
  _joyMove(e) {
    let dx = e.clientX - this.ox, dy = e.clientY - this.oy; const l = Math.hypot(dx, dy), R = this.joyR; if (l > R) { dx *= R / l; dy *= R / l; }
    this.knob.style.transform = `translate(${dx}px,${dy}px)`; const m = Math.min(1, l / R), dz = .1, k = m < dz ? 0 : (m - dz) / (1 - dz);
    this.move.x = l ? dx / Math.min(l, R) * k : 0; this.move.y = l ? -dy / Math.min(l, R) * k : 0;
  }
  _releaseJoy() { this.joyId = null; this.move.x = this.move.y = 0; this.knob.style.transform = ''; this.els.joy.classList.remove('active'); this.applyLayout(); }
  _bindCamera() {
    const a = this.camArea, ptr = new Map(), dist = () => { const p = [...ptr.values()]; return Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); };
    a.addEventListener('pointerdown', e => { if (this.editing) return; a.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); });
    a.addEventListener('pointermove', e => {
      const p = ptr.get(e.pointerId); if (!p) return; const before = ptr.size === 2 ? dist() : 0;
      if (ptr.size === 1) { this.cam.x += e.clientX - p.x; this.cam.y += e.clientY - p.y; }
      p.x = e.clientX; p.y = e.clientY; if (ptr.size === 2) this.zoom += dist() - before;
    });
    const up = e => ptr.delete(e.pointerId); a.addEventListener('pointerup', up); a.addEventListener('pointercancel', up);
    a.addEventListener('wheel', e => { e.preventDefault(); this.zoom -= e.deltaY * .5; }, { passive: false });
  }
  _bindKeys() {
    addEventListener('keydown', e => { if (!this.enabled) return; this.keys.add(e.code); const a = KEYS[e.code]; if (a && !e.repeat) this._fire(a, true); });
    addEventListener('keyup', e => { this.keys.delete(e.code); if (e.code === 'KeyJ') this.held.delete('attack'); });
  }
  poll() {
    let { x, y } = this.move; const k = this.keys;
    if (k.size) { const kx = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0), ky = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0); if (kx || ky) { const l = Math.hypot(kx, ky); x = kx / l; y = ky / l; } }
    return { move: { x, y }, actions: this.queue.splice(0) };
  }
  consumeCam() { const c = { x: this.cam.x, y: this.cam.y }; this.cam.x = this.cam.y = 0; return c; }
  consumeZoom() { const z = this.zoom; this.zoom = 0; return z; }
  setInteract(label) {
    const on = !!label; this.interactOn = on; this.els.interact.classList.toggle('off', !on && !this.editing); if (on) this.cap.textContent = label;
  }
  setCooldown(act, f) { this.els[act]?.style.setProperty('--cd', f.toFixed(3)); }
  applyLayout() {
    const c = S.ctl, ui = Math.max(.55, Math.min(1.15, innerHeight / 430)); this.layer.style.setProperty('--op', c.opacity);
    for (const id in DEFAULT_LAYOUT) {
      const d = { ...DEFAULT_LAYOUT[id], ...c.layout[id] }, e = this.els[id], size = d.size * ui * (id === 'joy' ? c.joySize : c.btnSize);
      e.style.width = e.style.height = size + 'px';
      const x = Math.max(0, Math.min(innerWidth - size, d.x)), y = Math.max(0, Math.min(innerHeight - size, d.y));
      e.style[d.s === 'r' ? 'right' : 'left'] = x + 'px'; e.style[d.s === 'r' ? 'left' : 'right'] = 'auto'; e.style.bottom = y + 'px';
    }
  }
  // Режим перемещения кнопок: перетаскивание сохраняется в настройках.
  beginEdit(done) {
    this.editing = true; this._done = done; this.setEnabled(true); this.enabled = false; this.layer.classList.add('editing'); this.els.interact.classList.remove('off');
    this.bar = el('edit-bar', this.layer); this.bar.innerHTML = '<span>Перетащите кнопки на удобные места</span>';
    const ok = el('pill', this.bar, 'button'); ok.textContent = 'Готово'; ok.onclick = () => this.endEdit();
  }
  endEdit() {
    this.editing = false; this.layer.classList.remove('editing'); this.bar?.remove(); this.setEnabled(false); this.setInteract(null); this._done?.();
  }
  _bindEdit() {
    let drag = null;
    this.layer.addEventListener('pointerdown', e => {
      if (!this.editing) return; const id = Object.keys(this.els).find(k => this.els[k].contains(e.target)); if (!id) return;
      const d = { ...DEFAULT_LAYOUT[id], ...S.ctl.layout[id] }; drag = { id, d, sx: e.clientX, sy: e.clientY, pid: e.pointerId }; this.layer.setPointerCapture(e.pointerId);
    });
    this.layer.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.pid) return; const { d } = drag, dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
      drag.pos = { s: d.s, x: Math.round(d.s === 'r' ? d.x - dx : d.x + dx), y: Math.round(d.y - dy), size: d.size }; S.ctl.layout[drag.id] = drag.pos; this.applyLayout();
    });
    const up = () => { if (drag?.pos) setLayout(drag.id, drag.pos); drag = null; }; this.layer.addEventListener('pointerup', up); this.layer.addEventListener('pointercancel', up);
  }
}
