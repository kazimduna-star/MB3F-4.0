import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { CONFIG } from '../config.js';
import { heightAt } from './world.js';
import { AssetCache } from './assets.js';
import { spawnMonsters } from './monsters.js';
import { makeSwirl } from './portal.js';
import { buildCity } from './city.js';

const rng = seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const std = (c, o = {}) => new THREE.MeshLambertMaterial({ color: c, flatShading: true, ...o });
const mesh = (g, m, shadow = true) => { const x = new THREE.Mesh(g, m); x.castShadow = shadow; x.receiveShadow = true; return x; };
const inst = (g, m, n, tint) => { const x = new THREE.InstancedMesh(g, m, n); x.castShadow = x.receiveShadow = true; x.frustumCulled = false; x.userData.tint = tint; return x; };

// Строители зон. Каждый возвращает {group, colliders, targets, interactables, update, applyGfx}.
function valley(def, world) {
  const R = rng(1337), group = new THREE.Group(), colliders = [], targets = [], interactables = [], d = new THREE.Object3D(), groups = {};
  const trunk = inst(new THREE.CylinderGeometry(.16, .26, 2.2, 6).translate(0, 1.1, 0), std(0x6a4a3a), 260);
  const crown = inst(mergeGeometries([new THREE.ConeGeometry(1.5, 3, 7).translate(0, 3.4, 0), new THREE.ConeGeometry(1.1, 2.4, 7).translate(0, 4.9, 0)]), std(0xffffff), 260,
    () => new THREE.Color([0x3f8f5a, 0x4aa56a, 0x5aa86a, 0x7a6fd6][Math.floor(R() * R() * 4)]));
  const rocks = inst(new THREE.DodecahedronGeometry(1, 0).scale(1, .7, 1), std(0x8a86a0), 80);
  const bushes = inst(new THREE.IcosahedronGeometry(.7, 0).translate(0, .4, 0), std(0x58a85a), 140);
  const flowers = inst(new THREE.SphereGeometry(.12, 6, 4).translate(0, .35, 0), std(0xffffff), 400, () => new THREE.Color([0xffffff, 0xff9ccf, 0x8fb4ff, 0xc9a2ff][Math.floor(R() * 4)]));
  const avoid = (x, z) => Math.hypot(x, z - 6) > 9 && Math.hypot(x - 12, z + 16) > 5 && Math.hypot(x + 10, z + 22) > 5;
  const place = (name, meshes, total, test, smin, smax, cr, ch) => {
    let n = 0; const list = [];
    for (let tries = 0; n < total && tries < total * 6; tries++) {
      const a = R() * 6.283, dd = Math.sqrt(R()) * 115, x = def.x + Math.cos(a) * dd, z = def.z + Math.sin(a) * dd, y = heightAt(x, z);
      if (!avoid(x, z) || !test(y)) continue;
      const s = smin + R() * (smax - smin); d.position.set(x, y, z); d.rotation.set(0, R() * 6.28, 0); d.scale.setScalar(s); d.updateMatrix();
      meshes.forEach(m => { m.setMatrixAt(n, d.matrix); if (m.userData.tint) m.setColorAt(n, m.userData.tint()); });
      if (cr) { const c = { x, z, r: cr * s, h: ch * s, i: n, group: name, active: true }; colliders.push(c); list.push(c); }
      n++;
    }
    meshes.forEach(m => { m.userData.total = n; m.count = n; m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; group.add(m); });
    groups[name] = { meshes, list, total: n };
  };
  if (!def.scatter) {
  place('trees', [trunk, crown], 260, y => y > -.3 && y < 15, .8, 1.6, .5, 5);
  place('rocks', [rocks], 80, y => y > -.5 && y < 20, .6, 2.2, .9, 1.2);
  place('bushes', [bushes], 140, y => y > -.3 && y < 12, .8, 1.5, 0, 0);
  place('flowers', [flowers], 400, y => y > -.3 && y < 8, .8, 1.4, 0, 0);
  }

  // Древний камень (интерактивный объект) и тренировочная мишень
  const bx = 12, bz = -16, by = heightAt(bx, bz), beacon = new THREE.Group(); beacon.position.set(bx, by, bz);
  beacon.add(mesh(new THREE.CylinderGeometry(.9, 1.1, .5, 8).translate(0, .25, 0), std(0x6f6c85)), mesh(new THREE.CylinderGeometry(.35, .45, 2.2, 6).translate(0, 1.6, 0), std(0x8a86a0)));
  const crystalMat = new THREE.MeshBasicMaterial({ color: 0x9d7bff }), crystal = mesh(new THREE.OctahedronGeometry(.5), crystalMat, false); crystal.position.y = 3.1; beacon.add(crystal);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.35, .35, 30, 12, 1, true), new THREE.MeshBasicMaterial({ color: 0xb59bff, transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.y = 18; beacon.add(beam);
  group.add(beacon); colliders.push({ x: bx, z: bz, r: 1, h: 3, active: true });
  interactables.push({ x: bx, z: bz, r: 3.2, label: 'Осмотреть камень', onUse(game) {
    if (world.flags.beacon) { game.hud.toast('Камень молчит. Путь к руинам лежит на северо-востоке.'); return; }
    world.flags.beacon = true; game.hud.toast('Камень Истока откликнулся. Он указывает путь к древним руинам.');
  } });

  const dx = -10, dz = -22, dy = heightAt(dx, dz), dummy = new THREE.Group(), body = new THREE.Group(); dummy.position.set(dx, dy, dz);
  const dm = std(0xc9a46a, { emissive: 0x000000 });
  body.add(mesh(new THREE.CylinderGeometry(.08, .08, 1.9, 6).translate(0, .95, 0), std(0x6a4a3a)), mesh(new THREE.BoxGeometry(.7, .9, .35).translate(0, 1.2, 0), dm), mesh(new THREE.SphereGeometry(.26, 10, 8).translate(0, 1.95, 0), dm));
  dummy.add(body); group.add(dummy); colliders.push({ x: dx, z: dz, r: .6, h: 2, active: true });
  const t = { x: dx, z: dz, r: .8, name: 'Тренировочная мишень', hp: 120, maxHp: 120, alive: true, flash: 0, respawn: 0,
    hit(dmg) { if (!this.alive) return; this.hp -= dmg; this.flash = .15; if (this.hp <= 0) { this.alive = false; this.respawn = 4; world.flags.dummy = true; body.visible = false; } } };
  targets.push(t);

  return { group, colliders, targets, interactables,
    update(dt, time) {
      crystal.rotation.y = time * 1.4; crystal.position.y = 3.1 + Math.sin(time * 2) * .12;
      const lit = world.flags.beacon; crystalMat.color.set(lit ? 0xffe28a : 0x9d7bff); beam.material.opacity = lit ? .4 : .22;
      if (t.flash > 0) { t.flash -= dt; dm.emissive.setHex(0x884422); body.rotation.z = Math.sin(t.flash * 60) * .08; } else { dm.emissive.setHex(0); body.rotation.z = 0; }
      if (!t.alive && (t.respawn -= dt) <= 0) { t.alive = true; t.hp = t.maxHp; body.visible = true; }
    },
    applyGfx(r) {
      const set = (g, f) => { if (!groups[g]) return; const n = Math.floor(groups[g].total * f); groups[g].meshes.forEach(m => m.count = n); groups[g].list.forEach(c => c.active = c.i < n); };
      set('trees', r.trees); ['rocks', 'bushes', 'flowers'].forEach(k => set(k, r.env));
    } };
}

function ruins(def, world) {
  const group = new THREE.Group(), colliders = [], stone = std(0x9b97b3), crystalMat = new THREE.MeshBasicMaterial({ color: 0x8ad0ff });
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2, x = def.x + Math.cos(a) * 9, z = def.z + Math.sin(a) * 9, y = heightAt(x, z), h = [5, 3.2, 4.5, 2.4, 5, 3.8, 2.8, 4.2][i];
    const p = mesh(new THREE.CylinderGeometry(.55, .65, h, 8).translate(0, h / 2, 0), stone); p.position.set(x, y - .3, z); group.add(p);
    const cap = mesh(new THREE.BoxGeometry(1.5, .35, 1.5).translate(0, h, 0), stone); cap.position.set(x, y - .3, z); group.add(cap);
    colliders.push({ x, z, r: .7, h: h + 1, active: true });
  }
  const cy = heightAt(def.x, def.z), altar = mesh(new THREE.BoxGeometry(2.4, 1, 2.4).translate(0, .5, 0), stone); altar.position.set(def.x, cy, def.z); group.add(altar);
  const crystal = mesh(new THREE.OctahedronGeometry(.6), crystalMat, false); group.add(crystal);
  colliders.push({ x: def.x, z: def.z, r: 1.7, h: 1.2, active: true });
  // Потерянный амулет (побочное задание «Потерянный амулет»)
  const amulet = mesh(new THREE.OctahedronGeometry(.25), new THREE.MeshBasicMaterial({ color: 0xffd86b }), false); amulet.position.set(def.x + 3, cy + 1.2, def.z); group.add(amulet);
  const interactables = [{ x: def.x + 3, z: def.z, r: 3, label: 'Поднять амулет', when: () => !world.flags.amulet, onUse(game) { world.flags.amulet = true; game.hud.toast('Вы нашли потерянный амулет. Отнесите его Лисе.', 4000); } }];
  return { group, colliders, targets: [], interactables,
    update(dt, time) { crystal.position.set(def.x, cy + 2 + Math.sin(time * 2) * .15, def.z); crystal.rotation.y = time; amulet.visible = !world.flags.amulet; amulet.rotation.y = time * 2; }, applyGfx() {} };
}

const empty = () => ({ group: new THREE.Group(), colliders: [], targets: [], interactables: [], update() {}, applyGfx() {} });

// Порталы и входы: оригинальная арка ancient-gateway + шейдерная плёнка в проёме. Положение плёнки задаётся в config (portal).
function gateway(def, world, kind) {
  const z = empty(), P = def.portal, T = CONFIG.teleports, sw = makeSwirl(P.w, P.h, kind === 'entrance' ? { a: [.1, .5, .4], b: [.2, .9, .7] } : null);
  const gx = def.x + P.sx, gz = def.z + P.sz, gy = heightAt(def.x, def.z) + P.sy; sw.mesh.position.set(gx, gy, gz); z.group.add(sw.mesh); let on = 0;
  if (kind === 'entrance') [-3.2, 3.2].forEach(dx => z.colliders.push({ x: def.x + dx, z: def.z, r: 1.8, h: 5, active: true }));
  else [-3.7, 3.7].forEach(dx => z.colliders.push({ x: def.x + dx, z: gz, r: 1.4, h: 6, active: true }));
  const label = { portal: 'Активировать портал', arena: 'Вернуться в мир', entrance: 'Войти в подземелье' }[kind];
  z.interactables.push({ x: gx, z: gz + 1.5, r: 6, label, onUse(game) {
    if (on > 0) return; on = 3; game.hud.toast(kind === 'arena' ? 'Портал уносит вас обратно...' : 'Портал пробуждается...');
    setTimeout(() => {
      if (kind === 'portal') { world.flags.portalUsed = true; delete world.flags['kill_lucifer-avatar']; world.flags.arenaChest = false; game.tele.go(T.arena); }   // повторный бой запускается только новой активацией
      else if (kind === 'arena') game.tele.go(T.back); else game.tele.go(T.dungeon);
    }, 1600);
  } });
  z.update = (dt, t) => { on = Math.max(0, on - dt); sw.update(t, on > 0); };
  return z;
}
// Сундук с наградой: появляется после победы над указанным боссом.
function addChest(z, world, o) {
  const g = new THREE.Group(); g.position.set(o.x, heightAt(o.x, o.z), o.z); g.visible = false;
  g.add(mesh(new THREE.BoxGeometry(1.4, .8, .9).translate(0, .4, 0), std(0x6a3f1e)), mesh(new THREE.BoxGeometry(1.5, .18, 1).translate(0, .88, 0), std(0xd9a93b)), mesh(new THREE.BoxGeometry(.2, .9, 1).translate(0, .45, 0), std(0xd9a93b)));
  z.group.add(g); const beaten = () => (world.flags[o.boss] || 0) > 0;
  z.interactables.push({ x: o.x, z: o.z, r: 3, label: 'Открыть сундук', when: () => beaten() && !world.flags[o.key], onUse(game) {
    world.flags[o.key] = true; game.player.inv.coins += o.coins; game.player.inv.stones += o.stones; game.hud.toast(`Награда: ${o.coins} монет, ${o.stones} Камней Истока`, 4000); } });
  const u = z.update; z.update = (dt, t) => { u(dt, t); g.visible = beaten() || !!world.flags[o.key]; };
}
const portalZone = (def, world) => gateway(def, world, 'portal');
const entranceZone = (def, world) => gateway(def, world, 'entrance');
function arenaZone(def, world) {
  const z = gateway(def, world, 'arena'); addChest(z, world, { x: def.x, z: def.z - 17, boss: 'kill_lucifer-avatar', key: 'arenaChest', coins: 5000, stones: 160 }); return z;
}
function dungeonZone(def, world) {
  const z = empty(), D = { x: def.x, z: def.z - 12 }, y0 = heightAt(def.x, def.z);
  [[-8.9, -9], [8.9, -9], [-8.9, 8.8], [8.9, 8.8], [-8.9, 32.5], [8.9, 32.5]].forEach(([dx, dz]) => z.colliders.push({ x: D.x + dx, z: D.z + dz, r: 1.1, h: 8, active: true }));   // колонны по плану зала
  const door = makeSwirl(2.2, 3, { a: [.1, .5, .4], b: [.2, .9, .7] }); door.mesh.position.set(D.x, y0 + 1.6, D.z - 10.2); z.group.add(door.mesh);
  z.interactables.push({ x: D.x, z: D.z - 8.6, r: 3.5, label: 'Покинуть подземелье', onUse(game) { game.tele.go(CONFIG.teleports.dungeonExit); } });
  addChest(z, world, { x: D.x, z: D.z + 34, boss: 'kill_the-apostate', key: 'dungeonChest', coins: 3000, stones: 80 });
  const u = z.update; z.update = (dt, t) => { u(dt, t); door.update(t, false); };
  return z;
}
// Жители: простые фигуры с именем над головой, их реплики и задания в scripts/quests.js
function addNpcs(z, def, world) {
  for (const n of def.npcs || []) {
    const g = new THREE.Group(), y = heightAt(n.x, n.z); g.position.set(n.x, y, n.z);
    g.add(mesh(new THREE.CapsuleGeometry(.3, .8, 4, 10).translate(0, .8, 0), std(n.color || 0x7a6fd6)), mesh(new THREE.SphereGeometry(.22, 12, 10).translate(0, 1.7, 0), std(0xf0c9a0)));
    const cv = document.createElement('canvas'); cv.width = 320; cv.height = 64; const x = cv.getContext('2d'); x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.lineWidth = 5; x.strokeStyle = '#1b1e4a'; x.fillStyle = '#fff';
    x.strokeText(n.name, 160, 42); x.fillText(n.name, 160, 42);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, depthWrite: false })); sp.scale.set(2.5, .5, 1); sp.position.y = 2.35; g.add(sp);
    z.group.add(g); z.colliders.push({ x: n.x, z: n.z, r: .5, h: 2, active: true });
    z.interactables.push({ x: n.x, z: n.z, r: 3, label: 'Поговорить', onUse(game) { game.quests.talk(n.id); } });
    const u = z.update; z.update = (dt, t) => { u(dt, t); g.position.y = y + Math.sin(t * 2 + n.x) * .02; if (world.player) g.rotation.y = Math.atan2(world.player.pos.x - n.x, world.player.pos.z - n.z); };
  }
  return z;
}
const emptyWithNpcs = (def, world) => addNpcs(empty(), def, world);
const BUILDERS = { valley, ruins, empty: emptyWithNpcs, portal: portalZone, entrance: entranceZone, arena: arenaZone, dungeon: dungeonZone };

// Одиночные модели, плитки (grid) и группы (at): оригинальные GLB, приведённые к метрам через fit.
async function placeProp(p, cache, group) {
  const q = new THREE.Quaternion(), v = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  const mk = (x, zz, ry = 0, s = 1, yy) => new THREE.Matrix4().compose(v.set(x, yy ?? heightAt(x, zz) + (p.dy || 0), zz), q.setFromAxisAngle(up, ry), new THREE.Vector3(s, s, s)); let meshes;
  if (p.merge) { meshes = await cache.merged(p.url, p.fit); const y = p.y ?? heightAt(p.x, p.z); meshes.forEach(m => { m.position.set(p.x, y, p.z); m.rotation.y = p.ry || 0; }); }
  else {
    let mats = [];
    if (p.grid) { const n = Math.ceil(p.grid.r / p.grid.step); for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) if (Math.hypot(i, j) * p.grid.step <= p.grid.r) mats.push(mk(p.x + i * p.grid.step, p.z + j * p.grid.step)); }
    else if (p.at) mats = p.at.map(([dx, dz, ry, s]) => mk(p.x + dx, p.z + dz, ry, s)); else mats = [mk(p.x, p.z, p.ry, 1, p.y)];
    meshes = await cache.instanced(p.url, mats, p.fit);
  }
  meshes.forEach(m => { if (p.noShadow) m.castShadow = false; group.add(m); }); return meshes;
}
const clear = (x, z) => CONFIG.pads.every(p => Math.hypot(x - p.x, z - p.z) > p.r + 6) && Math.hypot(x, z - 6) > 9 && Math.hypot(x - 12, z + 16) > 5 && Math.hypot(x + 10, z + 22) > 5;

// Расстановка оригинальных моделей Nature MegaKit инстансами (по несколько вариантов каждого типа).
async function scatter(def, cache, tick) {
  const R = rng(777), group = new THREE.Group(), colliders = [], groups = {}, q = new THREE.Quaternion(), p = new THREE.Vector3(), sc = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  for (const e of def.scatter) {
    tick?.();
    const per = e.urls.map(() => []), cols = e.urls.map(() => []); let n = 0;
    for (let tries = 0; n < e.n && tries < e.n * 8; tries++) {
      const a = R() * 6.283, dd = Math.sqrt(R()) * 115, x = def.x + Math.cos(a) * dd, z = def.z + Math.sin(a) * dd, y = heightAt(x, z);
      if (!clear(x, z) || y < -.3 || y > (e.hMax || 16)) continue;
      const s = e.s[0] + R() * (e.s[1] - e.s[0]), v = Math.floor(R() * e.urls.length);
      q.setFromAxisAngle(up, R() * 6.283); p.set(x, y, z); sc.setScalar(s);
      if (e.col) { const c = { x, z, r: e.col.r * s, h: e.col.h * s, active: true, k: per[v].length }; colliders.push(c); cols[v].push(c); }
      per[v].push(new THREE.Matrix4().compose(p, q, sc)); n++;
    }
    const recs = (groups[e.g] ??= []);
    for (let v = 0; v < e.urls.length; v++) {
      if (!per[v].length) continue;
      try { const meshes = await cache.instanced(e.urls[v], per[v]); meshes.forEach(m => group.add(m)); recs.push({ meshes, total: per[v].length, cols: cols[v] }); }
      catch (err) { console.warn('Не загружено', e.urls[v], err); cols[v].forEach(c => { c.active = false; }); }
    }
  }
  return { group, colliders, groups };
}

// Деревня из модульных кусков Medieval Village MegaKit (сетка 2 м: стены 2x3.12 м).
async function village(def, cache) {
  const group = new THREE.Group(), colliders = [], A = 'assets/buildings/medieval/', buckets = {}, q = new THREE.Quaternion(), p = new THREE.Vector3(), one = new THREE.Vector3(1, 1, 1), up = new THREE.Vector3(0, 1, 0);
  const put = (name, x, y, z, ry) => (buckets[name] ??= []).push(new THREE.Matrix4().compose(p.set(x, y, z), q.setFromAxisAngle(up, ry), one));
  for (const h of def.village.houses) {
    const n = h.n, c = Math.cos(h.rot), s = Math.sin(h.rot), hy = heightAt(def.x + h.x, def.z + h.z);
    const W = (lx, lz, la, name, dy = 0) => { const wx = def.x + h.x + lx * c + lz * s, wz = def.z + h.z - lx * s + lz * c; put(name, wx, hy + dy, wz, h.rot + la); return [wx, wz]; };
    const wall = h.brick ? 'Wall_UnevenBrick_' : 'Wall_Plaster_', str = wall + 'Straight', door = wall + 'Door_Round', win = h.brick ? str : 'Wall_Plaster_Window_Wide_Round';
    [[0, -1, 0, door], [0, 1, Math.PI, win], [1, 0, -Math.PI / 2, win], [-1, 0, Math.PI / 2, win]].forEach(([nx, nz, la, mid], si) => {
      for (let i = 0; i < n; i++) {
        const t = -n + 1 + 2 * i, isDoor = si === 0 && i === 1, [wx, wz] = nz ? W(t, nz * (n - .2), la, i === 1 ? mid : str) : W(nx * (n - .2), t, la, i === 1 ? mid : str);
        if (!isDoor) colliders.push({ x: wx, z: wz, r: 1, h: 3.2, active: true });
      }
    });
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) W(-n + 1 + 2 * i, -n + 1 + 2 * j, 0, 'Floor_WoodDark', .08);
    for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) W(sx * n, sz * n, 0, 'Corner_Exterior_Wood');
    W(0, 0, 0, n === 3 ? 'Roof_RoundTiles_6x6' : 'Roof_RoundTiles_4x4', 3.1);
  }
  put('Prop_Wagon', def.x + 5, heightAt(def.x + 5, def.z + 7), def.z + 7, .6);
  [[-4, 6], [-5.2, 6.8], [3, -6]].forEach(([x, z], i) => put('Prop_Crate', def.x + x, heightAt(def.x + x, def.z + z), def.z + z, i));
  for (const name of Object.keys(buckets)) {
    try { (await cache.instanced(A + name + '.gltf', buckets[name])).forEach(m => group.add(m)); } catch (e) { console.warn('Не загружено', name, e); }
  }
  return { group, colliders };
}

export class ZoneManager {
  constructor(scene, world) { this.scene = scene; this.world = world; this.loaded = new Map(); this.loading = new Set(); this.busy = false; this.loader = new GLTFLoader(); this.cache = new AssetCache(); this.gfx = null; }
  async load(def, onProgress) {
    if (this.loaded.has(def.id) || this.loading.has(def.id)) return; this.loading.add(def.id); this.busy = true;
    const steps = (def.scatter?.length || 0) + 3; let done = 0; const tick = () => onProgress?.(Math.min(.99, ++done / steps));
    try {
      const z = BUILDERS[def.builder](def, this.world); this.scene.add(z.group); z.extra = []; tick();
      if (def.scatter) {
        const s = await scatter(def, this.cache, tick); z.group.add(s.group); z.colliders.push(...s.colliders); const base = z.applyGfx;
        z.applyGfx = r => { base(r); for (const [g, list] of Object.entries(s.groups)) for (const rec of list) { const n = Math.floor(rec.total * (g === 'trees' ? r.trees : r.env)); rec.meshes.forEach(m => { m.count = n; }); rec.cols.forEach(c => { c.active = c.k < n; }); } };
      }
      z.deferred = [];
      for (const p of this.safe ? [] : def.props || []) { if (p.minEnv) z.deferred.push({ p, meshes: null, busy: false }); else { try { await placeProp(p, this.cache, z.group); } catch (e) { console.warn('Модель не загружена', p.url, e); } } }
      if (def.city) { const v = await buildCity(def, this.cache); z.group.add(v.group); z.colliders.push(...v.colliders); }
      if (def.village) { const v = await village(def, this.cache); z.group.add(v.group); z.colliders.push(...v.colliders); }
      if (def.monsters && !this.safe) {   // монстры подгружаются уже после старта игры: так пик памяти при загрузке ниже
        z.monsterTimer = setTimeout(async () => {
          if (!this.loaded.has(def.id)) return;
          try {
            const m = await spawnMonsters(def, this.world, (this.gfx?.aniso || 1) >= 4); if (!this.loaded.has(def.id)) return;
            z.group.add(m.group); z.targets.push(...m.targets); this.world.targets.push(...m.targets); z.extra.push(m.update);
          } catch (e) { console.warn('Монстры не загружены', def.id, e); }
        }, 2500);
      }
      for (const a of def.assets || []) {   // дополнительные внешние модели зоны
        try { const g = await this.loader.loadAsync(a.url), o = g.scene; o.position.set(a.x, a.y ?? heightAt(a.x, a.z), a.z); o.rotation.y = a.ry || 0; o.scale.setScalar(a.s || 1); z.group.add(o); }
        catch (e) { console.warn('Не удалось загрузить', a.url, e); }
      }
      this.world.colliders.push(...z.colliders); this.world.targets.push(...z.targets); this.world.interactables.push(...z.interactables);
      this.loaded.set(def.id, z); tick(); if (this.gfx) this.applyGfx(this.gfx);
    } catch (e) { console.error('Ошибка зоны', def.id, e); this.scene.remove(this.scene.children.find(c => c.userData.zone === def.id) || new THREE.Object3D()); }
    finally { this.busy = false; this.loading.delete(def.id); }
  }
  unload(id) {
    const z = this.loaded.get(id); if (!z) return; clearTimeout(z.monsterTimer); this.scene.remove(z.group);
    z.group.traverse(o => { o.geometry?.dispose(); [].concat(o.material || []).forEach(m => { for (const k in m) m[k]?.isTexture && m[k].dispose(); m.dispose(); }); o.dispose?.(); });
    const w = this.world; w.colliders = w.colliders.filter(c => !z.colliders.includes(c)); w.targets = w.targets.filter(c => !z.targets.includes(c)); w.interactables = w.interactables.filter(c => !z.interactables.includes(c));
    this.loaded.delete(id);
  }
  applyGfx(r) {
    this.gfx = r; const max = Math.min(r.aniso, this.maxAniso || 16);
    this.loaded.forEach(z => {
      (z.deferred || []).forEach(d => {   // тяжёлые модели грузятся только при нужном качестве окружения
        const ok = r.env >= d.p.minEnv;
        if (d.meshes) d.meshes.forEach(m => { m.visible = ok; }); else if (ok && !d.busy) { d.busy = true; placeProp(d.p, this.cache, z.group).then(ms => { d.meshes = ms; if (this.gfx) this.applyGfx(this.gfx); }).catch(e => console.warn('Модель не загружена', d.p.url, e)); }
      });
      z.applyGfx(r); z.group.traverse(o => [].concat(o.material || []).forEach(m => { for (const k in m) if (m[k]?.isTexture) m[k].anisotropy = max; })); });
  }
  update(dt, t, pos) {
    const load = this.gfx ? this.gfx.draw.zone : 70;
    for (const def of CONFIG.zones) {
      const d = Math.hypot(pos.x - def.x, pos.z - def.z), has = this.loaded.has(def.id);
      if (!has && !this.busy && d < def.radius + load) this.load(def);
      else if (has && def.id !== 'valley' && d > def.radius + load * 1.3) this.unload(def.id);
    }
    this.loaded.forEach(z => { z.update(dt, t); z.extra?.forEach(f => f(dt, t)); });
  }
  currentZone(pos) { return [...CONFIG.zones].sort((a, b) => a.radius - b.radius).find(z => Math.hypot(pos.x - z.x, pos.z - z.z) < z.radius * (z.id === 'valley' ? 1 : .6)); }
}
